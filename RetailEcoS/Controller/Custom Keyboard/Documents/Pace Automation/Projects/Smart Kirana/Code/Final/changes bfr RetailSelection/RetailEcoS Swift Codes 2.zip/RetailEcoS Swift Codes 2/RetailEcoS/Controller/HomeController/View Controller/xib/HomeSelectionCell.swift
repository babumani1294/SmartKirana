//
//  SelectRetailCell.swift
//  RetailEcoS
//
//  Created by Pace Automation on 2020-12-25.
//

import UIKit

class HomeSelectionCell: UITableViewCell {

    ///mark: propety
    
    
    ///mark: outlet
    
    @IBOutlet weak var viewCell: UIView!
    @IBOutlet weak var lblRetail: UILabel!
    @IBOutlet weak var imgCell: UIImageView!
    @IBOutlet weak var btnNxt: UIButton!
    
    
    ///mark: action
    
    @IBAction func btnNxt(_ sender: UIButton) {
        
    }
    
    override func awakeFromNib() {
        super.awakeFromNib()
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
    
    static var nib:UINib {
        return UINib(nibName: identifier, bundle: nil)
    }
    
    static var identifier: String {
        return String(describing: self)
    }
    
}
