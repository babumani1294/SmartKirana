//
//  SelectRetailVerticalVC.swift
//  RetailEcoS
//  SelectRetailVerticalVC
//  Description - This application handles all the retail verticals as listed.By selecting a retail vertical appropriate modules will be activated.
//  Developed By:
// © Copyright - Confluence Pte Ltd - Singapore - All Rights reserved

import UIKit

class HomeSelectionListController: UIViewController {
    
    ///mark: property
    var toolBar = UIToolbar()
    var picker  = UIPickerView()
    var getDateTime : String?
    var getCurrentTime = Timer()
    var retailVerticalDetails : [(UIImage,UIImage,UIImage, Bool,String)]?
    var getTimeZone : String?
    var getCountryPickerRow: Int?
    var getDeviceId: String?
    var getHomeListM: DeviceID!
    var getHomeControllerVM : HomeControllerViewModel!
    var getMenu : [Menu]!
    var getCountryFlagName = [(String,String,String)]()
    let minRowHeight: CGFloat = 50.0
    var activityIndicator = UIActivityIndicatorView()
    var strLabel = UILabel()
    let effectView = UIVisualEffectView(effect: UIBlurEffect(style: .dark))
  
    var homeSelectionDetails : [(UIImage,String)] = [(UIImage(named: "imgPostalCode")!,"dadsfj"),(UIImage(named: "imgShpFrmHome")!,"dfas"),(UIImage(named: "imgGroceryy")!,"dfasf"),(UIImage(named: "imgHomeDelivery")!,"Home Delivery"),(UIImage(named: "imgDeliveryAddress")!,"Not Found"),(UIImage(named: "imgMyShop")!,"My Shop"),(UIImage(named: "imgDeliveryTime")!,"Delivery Time")]
    
    var images = [UIImage(named: "imgAmerica"),UIImage(named: "imgAustralia"),UIImage(named: "imgBrazil"),UIImage(named: "ImgCanada"),UIImage(named: "imgChile"),UIImage(named: "imgColombia"),UIImage(named: "imgGuatemala"),UIImage(named: "imgIndia"),UIImage(named: "imgIndonesia"),UIImage(named: "imgMyanmar"),UIImage(named: "imgPoland"),UIImage(named: "imgSingapore"),UIImage(named: "imgSrilanka"),UIImage(named: "imgThailand")]
    
    
    var timeZones = ["GMT-5","GMT+11","GMT-3","GMT-5","GMT-3","GMT-5","GMT-6","GMT+5:30","GMT+7","GMT+6:30","GMT+1","GMT+8","GMT+5:30","GMT+7"]
    
    
    var labels : [(String)] =  [("USA"),("Australia"),("Brazil"),("Canada"),("Chile"),("Colombia"),("Guatemala"),("India"),("Indonesia"),("Myanmar"),("Poland"),("Singapore"),("Srilanka"),("Thailand")]
    
    var postalCode = ["0","1","2","3","4","5","6","7","8","9"]
    
    var requestType : RequestType = .post{
        didSet{
            switch requestType{
            case .get:
               
                
                showActivity(title: "Loading")
                
                getHomeControllerVM.getCountryName(vc: self, completions: {
                    guard let getCountryPickerDetails = self.getHomeControllerVM.getCountryPickerDetails else{
                        return
                    }
                    
                    for i in getCountryPickerDetails.status!.COUNTRY{
                        self.getCountryFlagName.append((i?.Country_flag ?? "not found", i?.Country_Name ?? "not found",i?.Postal_Code_Format ?? ""))
                    }
                    
                    self.pickerView.delegate = self
                    self.pickerView.dataSource = self
                    self.pickerView.reloadAllComponents()
                
                })
                
                
            
            case .post:
                
                showActivity(title: "Loading")
                
                ///mark: getting device id
                getDeviceId = UIDevice.current.identifierForVendor?.uuidString
                guard let getDeviceId = getDeviceId else {
                    showError(getError: "Invalid Device Id",getMessage: "Problem in getting device Id!")
                    return
                }
                
                getHomeListM = DeviceID(getDeviceId: getDeviceId)
                
                getHomeControllerVM.getHomeControllerDetails(postRequest: HelperClass.shared.getHomeDetails, sendDataModel: getHomeListM, vc: self, completion: { [self] in
                    
                    removeActivity()
                    
                    DispatchQueue.main.async {
                        
                        getMenu = getHomeControllerVM.getHomeControllerDetails.status?.Menu
                        
                        for i in 0...6{
                            homeSelectionDetails[i].1 = getMenu[i].val ?? "no value"
                        }
                        
                        
                        if let getPostal = getPostal{
                            homeSelectionDetails[0].1 = getPostal
                        }
                        
                        if let getDeliveryAddress = getDeliveryAddress{
                            homeSelectionDetails[4].1 = getDeliveryAddress
                        }
                        
                        for i in 0..<12{
                            
                            if let getRetailDetails = self.retailVerticalDetails{
                                print(getRetailDetails[i].3)
                                if getRetailDetails[i].3 {
                                    homeSelectionDetails[2].0 = getRetailDetails[i].1
                                    homeSelectionDetails[2].1 = getRetailDetails[i].4
                                }
                            }
                        }
                        
                        selectRetailTV.delegate = self
                        selectRetailTV.dataSource = self
                        selectRetailTV.reloadData()
                    }
                })
            }
        }
    }
    
    var pickerViewType : PickerViewType = .CountryPicker{
        didSet{
            switch pickerViewType{
            case .CountryPicker:
                self.showPicker(pickerAlpha: 1, toolbarAlpha: 1)
                pickerView.delegate = self
                pickerView.dataSource = self
                pickerView.reloadAllComponents()
                print("country picker started")
            case .PostalCodePicker:
                self.showPicker(pickerAlpha: 1, toolbarAlpha: 1)
                pickerView.delegate = self
                pickerView.dataSource = self
                pickerView.reloadAllComponents()
                print("postal picker started")
            }
        }
    }
    

    
    ///mark: outlet
    @IBOutlet weak var selectRetailTV: UITableView!
    @IBOutlet weak var btnLogin: UIButton!
    @IBOutlet weak var btnHome: UIButton!
    @IBOutlet weak var btnCountries: UIButton!
    @IBOutlet weak var lblTimeStamp: UILabel!
    @IBOutlet weak var pickerView: UIPickerView!
    @IBOutlet weak var viewTimeStamp: UIView!
    
    
    ///mark: action
    @IBAction func btnLogin(_ sender: UIButton) {
    }
    @IBAction func btnHome(_ sender: UIButton) {
    }
    @IBAction func btnCountries(_ sender: UIButton) {
        pickerViewType = .CountryPicker
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        initialConfig()
        
    }
    
    ///mark: function
    
    func initialConfig() {
        
        getHomeControllerVM = HomeControllerViewModel()
        getTimeZone = "GMT+5:30"
        getHomeControllerVM.showError = self
        getCurrentTime = Timer.scheduledTimer(timeInterval: 1, target: self,   selector: #selector(generateCurrentTimeStamp), userInfo: nil, repeats: true)
        
        
        selectRetailTV?.register(HomeSelectionCell.nib, forCellReuseIdentifier: HomeSelectionCell.identifier)
        
        ///mark:setting initial country flag
        if let getCountry = getCountry{
            for (index, element) in labels.enumerated(){
                if getCountry == element{
                    btnCountries.setImage(images[index], for: .normal)
                }
            }
            if labels.contains(getCountry){
                
            }else{
                showDisconnectAlert(title: "Error Found ", message: "No Country Found.")
            }
            
        }
        
        ///mark: initially hides pickerview
        showPicker(pickerAlpha: 0, toolbarAlpha: 0)
        
        requestType = .post
        
        requestType = .get
        
    }
    @objc func generateCurrentTimeStamp () {
        let formatter = DateFormatter()
        formatter.dateFormat = "E, d MMM / HH:mm:ss"
        formatter.timeZone = TimeZone(identifier: getTimeZone ?? "IST")
        getDateTime = (formatter.string(from: Date()) as NSString) as String
        if let getTimeDate = getDateTime {
//            lblTimeStamp.font = UIFont(name: "OpenSans", size: 20)
            lblTimeStamp.text = getTimeDate
        }else{
            showToas(message: "No Date & Time", seconds: 2)
        }
    }
    
    func showPicker(pickerAlpha: CGFloat,toolbarAlpha: CGFloat) {
        //        picker = UIPickerView.init()
        //        picker.delegate = self
        //        picker.dataSource = self
        //        if #available(iOS 13.0, *) {
        //            picker.backgroundColor = UIColor.systemGray4
        //        } else {
        //            picker.backgroundColor = UIColor.systemGray
        //
        //        }
        //        picker.setValue(UIColor.black, forKey: "textColor")
        //        picker.autoresizingMask = .flexibleWidth
        //        picker.contentMode = .center
        //        picker.showsSelectionIndicator = true
        //        picker.frame = CGRect.init(x: 0.0, y: UIScreen.main.bounds.size.height - 300, width: UIScreen.main.bounds.size.width, height: 300)
        //        self.view.addSubview(picker)
        pickerView.alpha = pickerAlpha
        pickerView.contentMode = .center
        toolBar = UIToolbar.init(frame: CGRect.init(x: 0.0, y: UIScreen.main.bounds.size.height - 300, width: UIScreen.main.bounds.size.width, height: 50))
        toolBar.barTintColor = UIColor.darkGray
        toolBar.alpha = toolbarAlpha
        
        let flexSpace = UIBarButtonItem(barButtonSystemItem: .flexibleSpace, target: nil, action: nil)
        let doneButton = UIBarButtonItem(title: "Done", style: .done, target: self, action: #selector(self.onDoneButtonTapped))
        let attributes: [NSAttributedStringKey : Any] = [ .font: UIFont.boldSystemFont(ofSize: 16) ]
        doneButton.setTitleTextAttributes(attributes, for: .normal)
        let cancelButton = UIBarButtonItem(title: "Cancel", style: .done, target: self, action: #selector(self.onCancelButtonTapped))
        doneButton.tintColor = UIColor.white
        cancelButton.tintColor = UIColor.white
        toolBar.setItems([cancelButton,flexSpace,doneButton], animated: false)
        self.view.addSubview(toolBar)
        toolBar.bottomAnchor.constraint(equalTo: pickerView.topAnchor, constant: 0).isActive = true
    }
    
    @objc func onDoneButtonTapped() {
        toolBar.removeFromSuperview()
//        self.btnCountries.setImage(URl(String: getCountryFlagName[getCountryPickerRow ?? 0].0 ), for: .normal)
        self.getTimeZone = timeZones[getCountryPickerRow ?? 0]
        pickerView.alpha = 0
        toolBar.alpha = 0
    }
    @objc func onCancelButtonTapped() {
        
        DispatchQueue.main.async {
            self.toolBar.removeFromSuperview()
            self.pickerView.alpha = 0
            self.toolBar.alpha = 0
        }
        
    }
    
}


///mark: extension

extension HomeSelectionListController: UITableViewDelegate,UITableViewDataSource{
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return homeSelectionDetails.count
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        if let cell = tableView.dequeueReusableCell(withIdentifier: HomeSelectionCell.identifier, for: indexPath) as? HomeSelectionCell {
            
            cell.lblRetail.text = homeSelectionDetails[indexPath.row].1
            cell.imgCell.image = homeSelectionDetails[indexPath.row].0
            
            if indexPath.row == 5 {
                cell.btnNxt.isUserInteractionEnabled = true
                cell.btnNxt.alpha = 1
            }else if indexPath.row == 6{
                cell.btnNxt.isUserInteractionEnabled = true
                cell.btnNxt.alpha = 1
            }
            
            
            return cell
        }
        
        return UITableViewCell()
    }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        
        let tHeight = tableView.frame.height
        let temp = tHeight / CGFloat(7)
        return temp > minRowHeight ? temp : minRowHeight
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        switch indexPath.row {
        case 0:
            pickerViewType = .PostalCodePicker
        default:
            print("")
        }
    }
    
}

extension HomeSelectionListController: UIPickerViewDataSource, UIPickerViewDelegate{
    
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        switch pickerViewType {
        case .CountryPicker:
            return 1
        case .PostalCodePicker:
            return 6
        }
        
    }
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        switch pickerViewType {
        case .CountryPicker:
            return getCountryFlagName.count
        case .PostalCodePicker:
            return postalCode.count
        }
        
    }
   
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String?
    {
        switch pickerViewType {
        case .CountryPicker:
            return getCountryFlagName[row].1
        case .PostalCodePicker:
            return postalCode[row]
        }
        
        
    }
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        
        switch pickerViewType {
        case .CountryPicker:
            getCountryPickerRow = row
        case .PostalCodePicker:
            print("")
        }
    }
    func pickerView(_ pickerView: UIPickerView, widthForComponent component: Int) -> CGFloat {
        return 50.0
    }
    func pickerView(_ pickerView: UIPickerView, rowHeightForComponent component: Int) -> CGFloat {
        return 60.0
    }
    func pickerView(_ pickerView: UIPickerView, viewForRow row: Int, forComponent component: Int, reusing view: UIView?) -> UIView {
        
        switch pickerViewType {
        case .CountryPicker:
            let parentView = UIView()
            
            let imageView = UIImageView(frame: CGRect(x: -38, y: 7.5, width: 77, height:45))
            let label = UILabel(frame: CGRect(x: 45, y: 5, width: 80, height: 50))
            
            
//            imageView.image = images[row]
            imageView.load(url: URL(string: getCountryFlagName[row].0)!)
            label.text = getCountryFlagName[row].1
            
            if #available(iOS 13.0, *) {
                picker.backgroundColor = UIColor.systemGray4
            } else {
                picker.backgroundColor = UIColor.systemGray
                
            }
            parentView.addSubview(label)
            parentView.addSubview(imageView)
            
            
            return parentView
        case .PostalCodePicker:
            let parentView = UIView()
            
            
            let label = UILabel(frame: CGRect(x: 10, y: 5, width: 80, height: 50))
            
            
            label.text = postalCode[row]
            
            if #available(iOS 13.0, *) {
                picker.backgroundColor = UIColor.systemGray4
            } else {
                picker.backgroundColor = UIColor.systemGray
                
            }
            parentView.addSubview(label)
            
            return parentView
        }
        return UIView()
    }
}



extension HomeSelectionListController: showError{
    func showError(getError: String, getMessage: String) {
        removeActivity()
        showDisconnectAlert(title: getError, message: getMessage)
    }
    
}

extension HomeSelectionListController{
    func showActivity(title: String) {
        
        DispatchQueue.main.async {
            self.strLabel.removeFromSuperview()
            self.activityIndicator.removeFromSuperview()
            self.effectView.removeFromSuperview()
            
            self.strLabel = UILabel(frame: CGRect(x: 50, y: 0, width: 160, height: 46))
            self.strLabel.text = title
            self.strLabel.font = .systemFont(ofSize: 14, weight: .medium)
            self.strLabel.textColor = UIColor(white: 0.9, alpha: 0.7)
            
            self.effectView.frame = CGRect(x: self.view.frame.midX - self.strLabel.frame.width/2, y: self.view.frame.midY - self.strLabel.frame.height/2 , width: 160, height: 46)
            self.effectView.layer.cornerRadius = 15
            self.effectView.layer.masksToBounds = true
            
            self.activityIndicator = UIActivityIndicatorView(activityIndicatorStyle: .white)
            self.activityIndicator.frame = CGRect(x: 0, y: 0, width: 46, height: 46)
            self.activityIndicator.isUserInteractionEnabled = false
            self.view.isUserInteractionEnabled = false
            self.activityIndicator.startAnimating()
            
            
            self.effectView.contentView.addSubview(self.activityIndicator)
            self.effectView.contentView.addSubview(self.strLabel)
            self.view.addSubview(self.effectView)
            
        }
        
    }
    func removeActivity() {
        
        DispatchQueue.main.async {
            
            self.activityIndicator.stopAnimating()
            self.effectView.removeFromSuperview()
            self.activityIndicator.removeFromSuperview()
            self.view.isUserInteractionEnabled = true
            
        }
        
    }
    func showToas(message : String, seconds: Double){
        
        DispatchQueue.main.async {
            let alert = UIAlertController(title: nil, message: message, preferredStyle: .alert)
            alert.view.backgroundColor = .black
            alert.view.alpha = 0.5
            alert.view.layer.cornerRadius = 15
            self.present(alert, animated: true)
            DispatchQueue.main.asyncAfter(deadline: DispatchTime.now() + seconds) {
                alert.dismiss(animated: true)
            }
            
        }
        
    }
    func showDisconnectAlert(title : String, message: String){
        
        DispatchQueue.main.async {
            let alert = UIAlertController(title: title, message: message, preferredStyle: UIAlertController.Style.alert)
            
            // add an action (button)
            let OkAction = UIAlertAction(title: "OK", style: UIAlertAction.Style.default){
                UIAlertAction in
                
            }
            let cancelAction = UIAlertAction(title: "Cancel", style: UIAlertAction.Style.cancel) {
                UIAlertAction in
                
            }
            alert.addAction(OkAction)
            alert.addAction(cancelAction)
            // show the alert
            self.present(alert, animated: true, completion: nil)
        }
        
    }
}


enum PickerViewType {
    case CountryPicker
    case PostalCodePicker
}
