//
//  RetailSelectionModel.swift
//  RetailEcoS
//
//  Created by Pace Automation on 2021-02-03.
//

import Foundation

class ModelToFetchRetails: Codable {
    var session : RetailSession
    var status : RetailStatus
}

class RetailSession : Codable{
    var SessionMessage : String
    var SessionResult : Int
}

class RetailStatus : Codable{
    var Vertical_Head : String?
    var Vertical_Head_Desc : String?
    var Message : String?
    var Error : String?
    var PERMISSION: [RetailVerticals]?
    var Result : Int?
}


class RetailVerticals : Codable{
    var val : String?
    var Id : String?
    var url : String?
    var status : String?
}


//{"session":{"SessionMessage":"Login Valid","SessionResult":1},"status":{"PERMISSION":[{"val":"Apparel","Id":"1","url":"https://www.smartkirana.ca/retailecos/Logo/Apparel.png","status":"0"},{"val":"Appliances","Id":"2","url":"https://www.smartkirana.ca/retailecos/Logo/Appliances.png","status":"0"},{"val":"Beauty Care","Id":"3","url":"https://www.smartkirana.ca/retailecos/Logo/Beauty Care.png","status":"0"},{"val":"Electrical","Id":"4","url":"https://www.smartkirana.ca/retailecos/Logo/Electrical.png","status":"0"},{"val":"Eyewear","Id":"5","url":"https://www.smartkirana.ca/retailecos/Logo/Eyewear.png","status":"0"},{"val":"Fashion","Id":"6","url":"https://www.smartkirana.ca/retailecos/Logo/Fashion.png","status":"0"},{"val":"Footwear","Id":"7","url":"https://www.smartkirana.ca/retailecos/Logo/Footwear.png","status":"0"},{"val":"Furniture","Id":"8","url":"https://www.smartkirana.ca/retailecos/Logo/Furniture.png","status":"0"},{"val":"Grocery","Id":"9","url":"https://www.smartkirana.ca/retailecos/Logo/Grocery.png","status":"0"},{"val":"Jewellery","Id":"10","url":"https://www.smartkirana.ca/retailecos/Logo/Jewellery.png","status":"0"},{"val":"Luggage","Id":"11","url":"https://www.smartkirana.ca/retailecos/Logo/Luggage.png","status":"0"},{"val":"Stationary","Id":"12","url":"https://www.smartkirana.ca/retailecos/Logo/Stationary.png","status":"0"}],"Message":"Success","Error":"You Should Select Grocery Only","Vertical_Head":"Select Retail Vertical","Vertical_Head_Desc":"What is your buying pleasure today?Select the Retail Vertical","Result":1}}
