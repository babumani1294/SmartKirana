//
//  HomeControllerModel.swift
//  RetailEcoS
//
//  Created by Pace Automation on 2021-02-10.
//

import Foundation


class HomeControllerModel: Codable {
    var session : HomeSession?
    var status : HomeStatus?
}

class HomeSession : Codable{
    var SessionMessage : String?
    var SessionResult : Int?
}

class HomeStatus : Codable{
    var Message : String?
    var Result : Int?
    var Menu : [Menu]
    var Menu_Head : String?
}

class Menu : Codable{
    var val : String?
    var Id : String?
    var status : String?
}






class CountryNameModel: Codable {
    var session : CountrySession?
    var status : CountryStatus?
}

class CountrySession : Codable{
    var SessionMessage : String?
    var SessionResult : Int?
}

class CountryStatus : Codable{
    var COUNTRY : [CountryDetails?]
}

class CountryDetails: Codable {
    var Currency_symbol : String?
    var Country_flag : String?
    var Country_Code : String?
    var Longitude : Double?
    var Postal_Code_Format : String?
    var Latitude : Double?
    var Country_Name : String?
    var Currency_code : String?
}

//{"session":{"SessionMessage":"Login Valid","SessionResult":1},"status":{"Message":"Success","Menu_Head_Desc":"What is your buying type today? Select the Menu","Menu":[{"val":"Postal Code","Id":"1","status":"0"},{"val":"Shop from Home","Id":"2","status":"0"},{"val":"Grocery","Id":"3","status":"0"},{"val":"Home Delivery","Id":"4","status":"0"},{"val":"Delivery Address","Id":"5","status":"0"},{"val":"My Shop","Id":"6","status":"0"},{"val":"Delivery Time","Id":"7","status":"0"}],"Menu_Head":"Select Menu","Result":1}}






class ModelToGetCountyAddress: Codable {
    var results : [CountryAddressResult?]
    var status : String?
}


class CountryAddressResult: Codable {
    var address_components  : [CountryAddressComponent?]
    var formatted_address : String?
    var geometry  : CountryGeometry?
    var place_id : String?
    var types : [String]
}

class CountryAddressComponent: Codable {
    var long_name  : String?
    var short_name : String?
    var types  : [String]
}

class CountryGeometry: Codable {
    var bounds : CountryViewPort?
    var location  : CountryLocation?
    var location_type : String?
    var viewport : CountryViewPort?
    
}

class CountryLocation: Codable {
    var lat  : Double?
    var lng  : Double?
}

class CountryViewPort: Codable {
    var northeast  : CountryLocation?
    var southwest  : CountryLocation?
}





//{
//   "results" : [
//      {
//         "address_components" : [
//            {
//               "long_name" : "600078",
//               "short_name" : "600078",
//               "types" : [ "postal_code" ]
//            },
//            {
//               "long_name" : "Chennai",
//               "short_name" : "Chennai",
//               "types" : [ "locality", "political" ]
//            },
//            {
//               "long_name" : "Tamil Nadu",
//               "short_name" : "TN",
//               "types" : [ "administrative_area_level_1", "political" ]
//            },
//            {
//               "long_name" : "India",
//               "short_name" : "IN",
//               "types" : [ "country", "political" ]
//            }
//         ],
//         "formatted_address" : "Chennai, Tamil Nadu 600078, India",
//         "geometry" : {
//            "bounds" : {
//               "northeast" : {
//                  "lat" : 13.0474429,
//                  "lng" : 80.2116812
//               },
//               "southwest" : {
//                  "lat" : 13.0308542,
//                  "lng" : 80.1881368
//               }
//            },
//            "location" : {
//               "lat" : 13.0410254,
//               "lng" : 80.2000596
//            },
//            "location_type" : "APPROXIMATE",
//            "viewport" : {
//               "northeast" : {
//                  "lat" : 13.0474429,
//                  "lng" : 80.2116812
//               },
//               "southwest" : {
//                  "lat" : 13.0308542,
//                  "lng" : 80.1881368
//               }
//            }
//         },
//         "place_id" : "ChIJh_WeI3FdUjoRtYkpIEDkq3U",
//         "types" : [ "postal_code" ]
//      }
//   ],
//   "status" : "OK"
//}




class ModelToGetCountyTimeZone: Codable {
    var dstOffset: Double?
    var rawOffset: Double?
    var status : String?
    var timeZoneId : String?
    var timeZoneName : String?
}





//{
//   "dstOffset" : 0,
//   "rawOffset" : -18000,
//   "status" : "OK",
//   "timeZoneId" : "America/New_York",
//   "timeZoneName" : "Eastern Standard Time"
//}



class DeviceID: Codable{
    
    var Device_id: String?
    
    init(getDeviceId: String) {
        self.Device_id = getDeviceId
    }
}
