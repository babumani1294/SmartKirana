//
//  SplashController.swift
//  RetailEcoS
//
//  Created by GBC  on 16/01/21.
//

import UIKit
import CoreLocation
import AVFoundation
import Photos
import Contacts


var getPostalCode: ModelToFetchCompanyDetails!
var sec = 0

var getCountry : String?
var getPostal: String?
var getDeliveryAddress : String?
var userCountyFlag : UIImageView?
var permissions  = (false,false,false,false,false)

class SplashController: UIViewController, CLLocationManagerDelegate {
    
    ///mark: property
    var getModelToGiveCountry: ModelToGiveCountry!
    var getSplashViewModel : SplashViewModel!
    var getDeviceId: String?
    var getLatitude: String?
    var getLongitude: String?
    var getTimeStamp: String?
    var lblColor = (UIColor.gray,UIColor.systemBlue,UIColor.orange)
    var activityIndicator = UIActivityIndicatorView()
    var strLabel = UILabel()
    let effectView = UIVisualEffectView(effect: UIBlurEffect(style: .dark))
    var locationManager = CLLocationManager()
    var currentLoc: CLLocation!
    var hasPermission = false
    var didFindLocation = false
    var new = [(String,String,String,Int)]()//title/logo/lapseTime/id
    var number = 0
    var count = 0
    
    ///mark: get/post Request
    var splashChange: RequestType = .get{
        
        didSet{
            
            switch splashChange {
            case .get:
                
                DispatchQueue.main.async {
                    var timer = Timer.scheduledTimer(withTimeInterval: Double(self.new[self.count].2) ?? 3, repeats: true){ [self] t in
                        
                        if self.count < self.new.count {
                            //                            self.imgLogo.load(url: URL(string: self.new[self.count].1 ?? "https://www.smartkirana.ca/retailecos/Logo/ServiceLogoCanada.png")! )
                            
                            // Create URL
                            let url = URL(string: self.new[self.count].1 ?? "https://www.smartkirana.ca/retailecos/Logo/ServiceLogoCanada.png")!
                            
                            // Fetch Image Data
                            if let data = try? Data(contentsOf: url) {
                                // Create Image and Update Image View
                                imgLogo.image = UIImage(data: data)
                            }
                            
                            self.lblTitle.text = self.new[self.count].0
                            self.count += 1
                        }else{
                            t.invalidate()
                            DispatchQueue.main.asyncAfter(deadline: .now() + 1) {
                                self.performSegue(withIdentifier: "showRetailVertical", sender: self)
                            }
                        }
                        
                    }
                }
                
                
            default:
                print("defa")
            }
        }
        
    }
    var requestType : RequestType = .post{
        didSet{
            switch requestType{
            case .get:
                showActivity(title: "Loading")
                guard let getLat = getLatitude, let getLong = getLongitude else {
                    showError(getError: "Problem in getting lat/long", getMessage: "")
                    return
                }
                getSplashViewModel.getCountryPostalCode(getLat: getLat, getLong: getLong, vc: self, completions: {
                    
                    guard let getCountryPostalCode = self.getSplashViewModel.getCountryPostalCode else{
                        return
                    }
                    
                    for i in getCountryPostalCode.results{
                        
                        if let geta = i?.address_components{
                            for j in i!.address_components{
                                
                                for i  in j!.types {
                                    if i == "postal_code"{
                                        getPostal = j!.long_name
                                        
                                    }
                                }
                                
                                for i  in j!.types {
                                    if i == "country"{
                                        getCountry = j!.long_name
                                        
                                    }
                                }
                                
                            }
                            getDeliveryAddress = i?.formatted_address
                        }
                    }
                    
                    self.removeActivity()
                    self.requestType = .post
                    
                })
            case .post:
                
                
                showActivity(title: "Loading")
                guard let getDeviceId = getDeviceId, let getTimeStamp = getTimeStamp, let getCountry = getCountry else {
                    showError(getError: "Problem in getting Device Id/ Time Stamp", getMessage: "")
                    return
                }
                
                getModelToGiveCountry = ModelToGiveCountry(getCountry: getCountry, getTimeStamp: getTimeStamp, getDeviceId: getDeviceId)
                
                getSplashViewModel.getCompanyDetails(postRequest: HelperClass.shared.urlFetchCompanyDetails, sendDataModel: getModelToGiveCountry, vc: self, completion: { [self] in
                    removeActivity()
                    getPostalCode = getSplashViewModel.getCompanyDetails
                    userCountyFlag?.load(url: URL(string: self.getSplashViewModel.getCompanyDetails.status.Country_flag ?? "https://www.smartkirana.ca/retailecos/assets/images/flag/flag-of-India.png")!)
                  
                    
                    if let getSplashList = getSplashViewModel.getCompanyDetails.status.splash{
                        
                        for i in getSplashList{
                            new.append((i.Title ?? "", i.Logo ?? "", i.Lapse_Time ?? "3", i.Id ?? 0))
                        }
                        
                        if count == 0{
                            var timer = Timer.scheduledTimer(withTimeInterval: Double(0) ?? 3, repeats: true){ t in
                                
                                if new.count > 0 {
                                    
                                    //                                                                        self.imgLogo.load(url: URL(string: new[0].1 ?? "https://www.smartkirana.ca/retailecos/Logo/ServiceLogoCanada.png")!)
                                    //
                                    
                                    // Create URL
                                    let url = URL(string: new[0].1 ?? "https://www.smartkirana.ca/retailecos/Logo/ServiceLogoCanada.png")!
                                    
                                    // Fetch Image Data
                                    if let data = try? Data(contentsOf: url) {
                                        // Create Image and Update Image View
                                        imgLogo.image = UIImage(data: data)
                                    }
                                    
                                    self.lblTitle.text = new[0].0
                                    count += 1
                                    t.invalidate()
                                    splashChange = .get
                                }else{
                                    showError(getError: "problem in appending received data!", getMessage: "")
                                }
                                
                            }
                        }
                        
                    }else{
                        showError(getError: "Splash Details not found!", getMessage: "")
                    }
                    
                })
                
            }
        }
    }
    
    //OpenSans
    //lbl.font = UIFont(name:"OpenSans",size:15)
    
    ///mark: outlet
    @IBOutlet weak var imgLogo: UIImageView!
    @IBOutlet weak var lblTitle: UILabel!
    @IBOutlet weak var viewCustomAlert: customAlerts!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        initialCofig()
    }
    override func viewDidAppear(_ animated: Bool) {
        print("view appeared")
    }
    
    
    ///mark: function
    func  initialCofig() {
        
        getSplashViewModel = SplashViewModel()
        getSplashViewModel.showError = self
        viewCustomAlert.btnClick = self
        getDeviceId = UIDevice.current.identifierForVendor?.uuidString
        getTimeStamp = generateCurrentTimeStamp()
        
        // Get Location Permission one time only
        locationManager.requestWhenInUseAuthorization()
        locationManager.delegate = self
        locationManager.desiredAccuracy = kCLLocationAccuracyBest
        locationManager.desiredAccuracy = kCLLocationAccuracyBest
        
        // Need to update location and get location data in locationManager object with delegate
        locationManager.startUpdatingLocation()
        locationManager.startMonitoringSignificantLocationChanges()
        
        //        permissions.0 ? permissions.1 ? permissions.2 ? permissions.3 ? permissions.4 ? print("") : showAlert(title: "Permission Needed!", message: "To Store Card Data", permissionTag: 1): showAlert(title: "Permission Needed!", message: "To AutoFill Data", permissionTag: 0) : self.showAlertToSettingPage(title: "Album Permissions Needed!", message: "You can give access in setting page!")  : self.showAlertToSettingPage(title: "Camera Permissions Needed!", message: "You can give access in setting page!") : self.showAlertToSettingPage(title: "Contact Permissions Needed!", message: "You can give access in setting page!")
        
    }
    func generateCurrentTimeStamp () -> String {
        let formatter = DateFormatter()
        formatter.dateFormat = "yyyy-MM-dd hh:mm:ss"
        return (formatter.string(from: Date()) as NSString) as String
    }
    
    
    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        manager.stopUpdatingLocation()
        manager.delegate = nil
        currentLoc = locations.first
        
        if let getCurrentLoc = currentLoc{
            getLatitude = String(getCurrentLoc.coordinate.latitude)
            getLongitude = String(getCurrentLoc.coordinate.longitude)
            requestType = .get
            
        }else{
            showError(getError: "Something Went Wrong!", getMessage: "Unable to get Location!")
        }
    }
    func locationManager(_ manager: CLLocationManager, didChangeAuthorization status: CLAuthorizationStatus) {
        
        switch status {
        case .authorizedAlways:
            print("")
        case .authorizedWhenInUse:
            print("")
        case .denied:
            print("")
            UIView.animate(withDuration: 1, animations: { [self] in
               
                self.viewCustomAlert.viewAlert.shadowEffects(shadow: .Alert, getView: self.viewCustomAlert.viewAlert, cornerRadius: 12)
                self.viewCustomAlert.lblAlertMessage.text = "The application requires to use your current location to provide important Geo position information on the stores, provide delivery address etc., and without this permission the application cannot work"
                self.viewCustomAlert.lblAlertTitle.text = "ERROR!"
                self.viewCustomAlert.alpha = 1
            }, completion: nil)
        case .notDetermined:
            print("")
            
        default:
            print("")
        }
        
    }
    
}



///mark: extension

extension SplashController: alertButtonclickEvent{
    func alertButtonClickEvent(Btn: UIButton) {
        UIView.animate(withDuration: 1, animations: { [self] in
            self.viewCustomAlert.alpha = 0
            exit(0)
        }, completion: nil)
    }
}

extension SplashController: showError{
    func showError(getError: String, getMessage: String) {
        removeActivity()
        showDisconnectAlert(title: getError, message: getMessage)
    }
}

extension SplashController{
    func showActivity(title: String) {
        
        DispatchQueue.main.async {
            self.strLabel.removeFromSuperview()
            self.activityIndicator.removeFromSuperview()
            self.effectView.removeFromSuperview()
            
            self.strLabel = UILabel(frame: CGRect(x: 50, y: 0, width: 160, height: 46))
            self.strLabel.text = title
            self.strLabel.font = .systemFont(ofSize: 14, weight: .medium)
            self.strLabel.textColor = UIColor(white: 0.9, alpha: 0.7)
            
            self.effectView.frame = CGRect(x: self.view.frame.midX - self.strLabel.frame.width/2, y: self.view.frame.midY - self.strLabel.frame.height/2 , width: 160, height: 46)
            self.effectView.layer.cornerRadius = 15
            self.effectView.layer.masksToBounds = true
            
            self.activityIndicator = UIActivityIndicatorView(activityIndicatorStyle: .white)
            self.activityIndicator.frame = CGRect(x: 0, y: 0, width: 46, height: 46)
            self.activityIndicator.isUserInteractionEnabled = false
            self.view.isUserInteractionEnabled = false
            self.activityIndicator.startAnimating()
            
            
            self.effectView.contentView.addSubview(self.activityIndicator)
            self.effectView.contentView.addSubview(self.strLabel)
            self.view.addSubview(self.effectView)
            
        }
        
    }
    func removeActivity() {
        
        DispatchQueue.main.async {
            
            self.activityIndicator.stopAnimating()
            self.effectView.removeFromSuperview()
            self.activityIndicator.removeFromSuperview()
            self.view.isUserInteractionEnabled = true
            
        }
        
    }
    func showToas(message : String, seconds: Double){
        
        DispatchQueue.main.async {
            let alert = UIAlertController(title: nil, message: message, preferredStyle: .alert)
            alert.view.backgroundColor = .black
            alert.view.alpha = 0.5
            alert.view.layer.cornerRadius = 15
            self.present(alert, animated: true)
            DispatchQueue.main.asyncAfter(deadline: DispatchTime.now() + seconds) {
                alert.dismiss(animated: true)
            }
            
        }
        
    }
    func showAlert(title : String, message: String,permissionTag: Int){
        
        DispatchQueue.main.async {
            let alert = UIAlertController(title: title, message: message, preferredStyle: UIAlertController.Style.alert)
            
            // add an action (button)
            let OkAction = UIAlertAction(title: "OK", style: UIAlertAction.Style.default){
                UIAlertAction in
                
                if permissionTag == 0{
                    permissions.3 = true
                }else{
                    permissions.4 = true
                }
                
            }
            let cancelAction = UIAlertAction(title: "Cancel", style: UIAlertAction.Style.cancel) {
                UIAlertAction in
                
            }
            alert.addAction(OkAction)
            alert.addAction(cancelAction)
            
            alert.addAction(OkAction)
            
            // show the alert
            self.present(alert, animated: true, completion: nil)
        }
        
    }
    func showAlertToSettingPage(title : String, message: String){
        
        DispatchQueue.main.async {
            let alert = UIAlertController(title: title, message: message, preferredStyle: UIAlertController.Style.alert)
            
            // add an action (button)
            let OkAction = UIAlertAction(title: "OK", style: UIAlertAction.Style.default){
                UIAlertAction in
                guard let settingsUrl = URL(string: UIApplicationOpenSettingsURLString) else {
                    return
                }
                if UIApplication.shared.canOpenURL(settingsUrl) {
                    UIApplication.shared.open(settingsUrl, completionHandler: { (success) in })
                }
                
            }
            
            alert.addAction(OkAction)
            
            // show the alert
            self.present(alert, animated: true, completion: nil)
        }
        
    }
    func showDisconnectAlert(title : String, message: String){
        
        DispatchQueue.main.async {
            let alert = UIAlertController(title: title, message: message, preferredStyle: UIAlertController.Style.alert)
            
            // add an action (button)
            let OkAction = UIAlertAction(title: "OK", style: UIAlertAction.Style.default){
                UIAlertAction in
                
                self.performSegue(withIdentifier: "showRetailVertical", sender: self)
            }
            let cancelAction = UIAlertAction(title: "Cancel", style: UIAlertAction.Style.cancel) {
                UIAlertAction in
                self.performSegue(withIdentifier: "showRetailVertical", sender: self)
            }
            alert.addAction(OkAction)
            alert.addAction(cancelAction)
            // show the alert
            self.present(alert, animated: true, completion: nil)
        }
        
    }
}



