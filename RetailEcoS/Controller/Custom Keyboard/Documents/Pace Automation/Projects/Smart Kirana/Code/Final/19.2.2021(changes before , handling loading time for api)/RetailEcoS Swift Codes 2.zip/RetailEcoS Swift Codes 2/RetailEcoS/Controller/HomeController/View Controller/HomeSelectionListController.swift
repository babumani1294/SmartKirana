//
//  SelectRetailVerticalVC.swift
//  RetailEcoS
//  SelectRetailVerticalVC
//  Description - This application handles all the retail verticals as listed.By selecting a retail vertical appropriate modules will be activated.
//  Developed By:
// © Copyright - Confluence Pte Ltd - Singapore - All Rights reserved

import UIKit

///America/New_York
///Eastern Standard Time

class HomeSelectionListController: UIViewController {
    
    ///mark: property
    var toolBar = UIToolbar()
    var picker  = UIPickerView()
    var getDateTime : String?
    var getLatitude: Double?
    var getLongitude: Double?
    var getCurrentTime = Timer()
    var retailVerticalDetails : [(UIImage?,UIImage?,UIImage?, Bool,String)]?
    var getTimeZone : String?
    var getCountryPickerRow: Int?
    var getDeviceId: String?
    var isShowingPicker: Bool = false
    var getHomeListM: DeviceID!
    var getHomeControllerVM : HomeControllerViewModel!
    var getMenu : [Menu]!
    var getCountryFlagName = [(UIImage?,String,String)]()
    var getRequestType = (false,false,false)//requestCountries/reqCountryAddress/reqCountryTime
    var getPostalCodeFormat = [Character]()
    var getFinalPostalCode = [Character]()
    let minRowHeight: CGFloat = 50.0
    var activityIndicator = UIActivityIndicatorView()
    var strLabel = UILabel()
    let effectView = UIVisualEffectView(effect: UIBlurEffect(style: .dark))
    
    var homeSelectionDetails : [(UIImage,String)] = [(UIImage(named: "imgPostalCode")!,"dadsfj"),(UIImage(named: "imgShpFrmHome")!,"dfas"),(UIImage(named: "imgGroceryy")!,"dfasf"),(UIImage(named: "imgHomeDelivery")!,"Home Delivery"),(UIImage(named: "imgDeliveryAddress")!,"Not Found"),(UIImage(named: "imgMyShop")!,"My Shop"),(UIImage(named: "imgDeliveryTime")!,"Delivery Time")]
    
    var images = [UIImage(named: "imgAmerica"),UIImage(named: "imgAustralia"),UIImage(named: "imgBrazil"),UIImage(named: "ImgCanada"),UIImage(named: "imgChile"),UIImage(named: "imgColombia"),UIImage(named: "imgGuatemala"),UIImage(named: "imgIndia"),UIImage(named: "imgIndonesia"),UIImage(named: "imgMyanmar"),UIImage(named: "imgPoland"),UIImage(named: "imgSingapore"),UIImage(named: "imgSrilanka"),UIImage(named: "imgThailand")]
    
    
    var timeZones = ["GMT-5","GMT+11","GMT-3","GMT-5","GMT-3","GMT-5","GMT-6","GMT+5:30","GMT+7","GMT+6:30","GMT+1","GMT+8","GMT+5:30","GMT+7"]
    var labels : [(String)] =  [("USA"),("Australia"),("Brazil"),("Canada"),("Chile"),("Colombia"),("Guatemala"),("India"),("Indonesia"),("Myanmar"),("Poland"),("Singapore"),("Srilanka"),("Thailand")]
    
    var postalCode = ["0","1","2","3","4","5","6","7","8","9"]
    var alphabeticList = ["A","B","C","D","E","F","G","H","I","J","K","L","M","N","O","P","Q","R","S","T","U","V","W","X","Y","Z"]
    var numericList = ["0","1","2","3","4","5","6","7","8","9"]
    
    var requestType : RequestType = .post{
        didSet{
            switch requestType{
            case .get:
                
                
                if getRequestType.0{
                    
                    showActivity(title: "Loading")
                    
                    getHomeControllerVM.getCountryName(vc: self, completions: {
                        
                        self.removeActivity()
                        
                        guard let getCountryPickerDetails = self.getHomeControllerVM.getCountryPickerDetails else{
                            return
                        }
                        
                        for i in getCountryPickerDetails.status!.COUNTRY{
                            
                            let getCountryFlagUrl = URL(string: i?.Country_flag ?? "")!
                            
                            // Fetch Image Data
                            if let getCountryFlagData = try? Data(contentsOf: getCountryFlagUrl) {
                                // Create Image and Update Image View
                                self.getCountryFlagName.append((UIImage(data: getCountryFlagData), i?.Country_Name ?? "not found",i?.Postal_Code_Format ?? ""))
                                print(i?.Country_Name,i?.Postal_Code_Format)
                            }
                            
                        }
                        
                        self.pickerView.delegate = self
                        self.pickerView.dataSource = self
                        self.pickerView.reloadAllComponents()
                        
                    })
                }else{
                    if getRequestType.1{
                        showActivity(title: "Loading")
                        
                        getHomeControllerVM.getCountryAddress(getPostalCode: String(self.getFinalPostalCode), vc: self, completions:  {
                            
                            self.removeActivity()
                            
                            guard let getCountryPickerDetails = self.getHomeControllerVM.getCountryAddress else{
                                return
                            }
                            
                            if self.getHomeControllerVM.getCountryAddress.status == "OK"{
                                
                                for i in self.getHomeControllerVM.getCountryAddress.results{
                                    self.homeSelectionDetails[4].1 = i?.formatted_address ?? "found nil value"
                                    
                                    self.getLongitude = i?.geometry?.location?.lng
                                    self.getLatitude = i?.geometry?.location?.lat
                                    
                                }
                                self.selectRetailTV.reloadData()
                                self.getRequestType.0 = false
                                self.getRequestType.1 = false
                                self.getRequestType.2 = true
                                self.requestType = .get
                                
                            }else{
                                self.showError(getError: "Error!", getMessage: "please give valid Postal code.")
                            }
                            
                            
                            
                        })
                    }else{
                        if getRequestType.2{
                            
                            
                            if let getLongitude = self.getLongitude, let getLatitude = self.getLatitude{
                                
                                
                                showActivity(title: "Loading")
                                
                                getHomeControllerVM.getCountryTimeZone(getLat: String(getLatitude), getLong: String(getLongitude), getTimeStamp: "00", vc: self, completions:  {
                                    
                                    self.removeActivity()
                                    
                                    guard let getCountryTimeZone = self.getHomeControllerVM.getCountryTimeZone else{
                                        return
                                    }
                                    
                                    if self.getHomeControllerVM.getCountryTimeZone.status == "OK"{
                                        
                                        
                                        if let getTimeZone = self.getHomeControllerVM.getCountryTimeZone.timeZoneId{
                                            self.getTimeZone = getTimeZone
                                        }
                                        
                                    }else{
                                        self.showError(getError: "Error!", getMessage: "problem in getting time zone for country.")
                                    }
                                    
                                    
                                    
                                })
                                
                                
                                
                                
                            }else{
                                self.showError(getError: "Error!", getMessage: "Problem in getting lat/long from server!")
                            }
                            
                        }else{
                            
                        }
                    }
                }
                
                
            //                showActivity(title: "Loading")
            //
            //                getHomeControllerVM.getCountryName(vc: self, completions: {
            //
            //                    self.removeActivity()
            //
            //                    guard let getCountryPickerDetails = self.getHomeControllerVM.getCountryPickerDetails else{
            //                        return
            //                    }
            //
            //                    for i in getCountryPickerDetails.status!.COUNTRY{
            //
            //                        let getCountryFlagUrl = URL(string: i?.Country_flag ?? "")!
            //
            //                        // Fetch Image Data
            //                        if let getCountryFlagData = try? Data(contentsOf: getCountryFlagUrl) {
            //                            // Create Image and Update Image View
            //                            self.getCountryFlagName.append((UIImage(data: getCountryFlagData), i?.Country_Name ?? "not found",i?.Postal_Code_Format ?? ""))
            //                            print(i?.Country_Name,i?.Postal_Code_Format)
            //                        }
            //
            //                    }
            //
            //                    self.pickerView.delegate = self
            //                    self.pickerView.dataSource = self
            //                    self.pickerView.reloadAllComponents()
            //
            //                })
            
            
            
            case .post:
                
                showActivity(title: "Loading")
                
                ///mark: getting device id
                getDeviceId = UIDevice.current.identifierForVendor?.uuidString
                guard let getDeviceId = getDeviceId else {
                    showError(getError: "Invalid Device Id",getMessage: "Problem in getting device Id!")
                    return
                }
                
                getHomeListM = DeviceID(getDeviceId: getDeviceId)
                
                getHomeControllerVM.getHomeControllerDetails(postRequest: HelperClass.shared.getHomeDetails, sendDataModel: getHomeListM, vc: self, completion: { [self] in
                    
                    removeActivity()
                    
                    DispatchQueue.main.async {
                        
                        getMenu = getHomeControllerVM.getHomeControllerDetails.status?.Menu
                        
                        for i in 0...6{
                            homeSelectionDetails[i].1 = getMenu[i].val ?? "no value"
                        }
                        
                        
                        if let getPostal = getPostal{
                            homeSelectionDetails[0].1 = getPostal
                        }
                        
                        if let getDeliveryAddress = getDeliveryAddress{
                            homeSelectionDetails[4].1 = getDeliveryAddress
                        }
                        
                        for i in 0..<12{
                            
                            if let getRetailDetails = self.retailVerticalDetails{
                                print(getRetailDetails[i].3)
                                if getRetailDetails[i].3 {
                                    homeSelectionDetails[2].0 = getRetailDetails[i].1 ?? UIImage(named: "imgError")!
                                    homeSelectionDetails[2].1 = getRetailDetails[i].4
                                }
                            }
                        }
                        
                        selectRetailTV.delegate = self
                        selectRetailTV.dataSource = self
                        selectRetailTV.reloadData()
                    }
                })
            }
        }
    }
    
    var pickerViewType : PickerViewType = .CountryPicker{
        didSet{
            switch pickerViewType{
            case .CountryPicker:
                isShowingPicker = true
                self.showPicker(pickerAlpha: 1, toolbarAlpha: 1)
                print("country picker started")
            case .PostalCodePicker:
                isShowingPicker = true
                self.showPicker(pickerAlpha: 1, toolbarAlpha: 1)
                print("postal picker started")
            }
        }
    }
    
    
    
    ///mark: outlet
    @IBOutlet weak var selectRetailTV: UITableView!
    @IBOutlet weak var btnLogin: UIButton!
    @IBOutlet weak var btnHome: UIButton!
    @IBOutlet weak var btnCountries: UIButton!
    @IBOutlet weak var lblTimeStamp: UILabel!
    @IBOutlet weak var pickerView: UIPickerView!
    @IBOutlet weak var viewTimeStamp: UIView!
    
    
    ///mark: action
    @IBAction func btnLogin(_ sender: UIButton) {
    }
    @IBAction func btnHome(_ sender: UIButton) {
    }
    @IBAction func btnCountries(_ sender: UIButton) {
        if isShowingPicker{
            
        }else{
            pickerViewType = .CountryPicker
        }
        
    }
    //    getCountryPostalCode
    override func viewDidLoad() {
        super.viewDidLoad()
        initialConfig()
        
    }
    
    ///mark: function
    
    func initialConfig() {
        
        getHomeControllerVM = HomeControllerViewModel()
        getHomeControllerVM.showError = self
        
        if let getIntTimeZone = getCountryTimeZone{
            getTimeZone = getIntTimeZone
        }
        
        getCurrentTime = Timer.scheduledTimer(timeInterval: 1, target: self,   selector: #selector(generateCurrentTimeStamp), userInfo: nil, repeats: true)
        
        selectRetailTV?.register(HomeSelectionCell.nib, forCellReuseIdentifier: HomeSelectionCell.identifier)
        
        ///mark:setting initial country flag
        if let getCountryFlag = userCountyFlag, let postalCodeFormat = getCountryPostalCode{
            btnCountries.setImage(getCountryFlag, for: .normal)
            self.getPostalCodeFormat = Array(postalCodeFormat)
            self.getFinalPostalCode.removeAll()
            for (index,element) in self.getPostalCodeFormat.enumerated(){
                //                if element == "N"{
                //                    self.getFinalPostalCode.append("0")
                //                }else{
                //                    self.getFinalPostalCode.append("A")
                //                }
                if element == "N"{
                    self.getFinalPostalCode.append("0")
                }else if element == "S"{
                    self.getFinalPostalCode.append(" ")
                }else if element == "A"{
                    self.getFinalPostalCode.append("A")
                }
                
            }
            
            print(self.getFinalPostalCode)
        }else{
            self.showError(getError: "Error!", getMessage: "Problem in getting Country Flag or Postal Code Format!")
        }
        
        
        
        ///mark: initially hides pickerview
        showPicker(pickerAlpha: 0, toolbarAlpha: 0)
        
        requestType = .post
        getRequestType.0 = true
        getRequestType.1 = false
        getRequestType.2 = false
        requestType = .get
        
        
    }
    
    func showPicker(pickerAlpha: CGFloat,toolbarAlpha: CGFloat) {
        
        pickerView.alpha = pickerAlpha
        pickerView.contentMode = .center
        toolBar = UIToolbar.init(frame: CGRect.init(x: 0.0, y: UIScreen.main.bounds.size.height - 300, width: UIScreen.main.bounds.size.width, height: 50))
        toolBar.barTintColor = UIColor.darkGray
        toolBar.alpha = toolbarAlpha
        
        let flexSpace = UIBarButtonItem(barButtonSystemItem: .flexibleSpace, target: nil, action: nil)
        let doneButton = UIBarButtonItem(title: "Done", style: .done, target: self, action: #selector(self.onDoneButtonTapped))
        let attributes: [NSAttributedStringKey : Any] = [ .font: UIFont.boldSystemFont(ofSize: 16) ]
        doneButton.setTitleTextAttributes(attributes, for: .normal)
        let cancelButton = UIBarButtonItem(title: "Cancel", style: .done, target: self, action: #selector(self.onCancelButtonTapped))
        doneButton.tintColor = UIColor.white
        cancelButton.tintColor = UIColor.white
        toolBar.setItems([cancelButton,flexSpace,doneButton], animated: false)
        self.view.addSubview(toolBar)
        toolBar.bottomAnchor.constraint(equalTo: pickerView.topAnchor, constant: 0).isActive = true
        pickerView.delegate = self
        pickerView.dataSource = self
        pickerView.reloadAllComponents()
    }
    
    
    @objc func generateCurrentTimeStamp () {
        let formatter = DateFormatter()
        formatter.dateFormat = "E, d MMM / HH:mm:ss"
        print(getTimeZone)
        formatter.timeZone = TimeZone(identifier: getTimeZone ?? "IST")
        getDateTime = (formatter.string(from: Date()) as NSString) as String
        if let getTimeDate = getDateTime {
            //            lblTimeStamp.font = UIFont(name: "OpenSans", size: 20)
            lblTimeStamp.text = getTimeDate
        }else{
            showToas(message: "No Date & Time", seconds: 2)
        }
    }
    @objc func onDoneButtonTapped() {
        
        DispatchQueue.main.async {
            
            //            let removeSpaceChar = self.getCountryFlagName[self.getCountryPickerRow ?? 0].2.replacingOccurrences(of: "S", with: "", options: NSString.CompareOptions.literal, range:nil)
            //
            //            self.getPostalCodeFormat = Array(removeSpaceChar)
            
            self.getPostalCodeFormat = Array(self.getCountryFlagName[self.getCountryPickerRow ?? 0].2)
            
            switch self.pickerViewType{
            case .CountryPicker:
                self.btnCountries.setImage(self.getCountryFlagName[self.getCountryPickerRow ?? 0].0, for: .normal)
                self.getFinalPostalCode.removeAll()
                for (index,element) in self.getPostalCodeFormat.enumerated(){
                    if element == "N"{
                        self.getFinalPostalCode.append("0")
                    }else if element == "S"{
                        self.getFinalPostalCode.append(" ")
                    }else if element == "A"{
                        self.getFinalPostalCode.append("A")
                    }
                    
                }
                print(self.getFinalPostalCode)
                
            case .PostalCodePicker:
                self.homeSelectionDetails[0].1 =  String(self.getFinalPostalCode)
                self.selectRetailTV.reloadData()
                self.getRequestType.0 = false
                self.getRequestType.1 = true
                self.getRequestType.2 = false
                self.requestType = .get
                
            }
            //            self.getTimeZone = self.timeZones[self.getCountryPickerRow ?? 0]
            self.pickerView.alpha = 0
            self.toolBar.alpha = 0
            self.isShowingPicker = false
            self.view.layoutIfNeeded()
        }
        
    }
    @objc func onCancelButtonTapped() {
        
        DispatchQueue.main.async {
            self.pickerView.alpha = 0
            self.toolBar.alpha = 0
            self.isShowingPicker = false
            self.view.layoutIfNeeded()
        }
        
    }
    
}


///mark: extension

extension HomeSelectionListController: UITableViewDelegate,UITableViewDataSource{
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return homeSelectionDetails.count
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        if let cell = tableView.dequeueReusableCell(withIdentifier: HomeSelectionCell.identifier, for: indexPath) as? HomeSelectionCell {
            
            cell.lblRetail.text = homeSelectionDetails[indexPath.row].1
            cell.imgCell.image = homeSelectionDetails[indexPath.row].0
            
            if indexPath.row == 5 {
                cell.btnNxt.isUserInteractionEnabled = true
                cell.btnNxt.alpha = 1
            }else if indexPath.row == 6{
                cell.btnNxt.isUserInteractionEnabled = true
                cell.btnNxt.alpha = 1
            }
            
            
            return cell
        }
        
        return UITableViewCell()
    }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        
        let tHeight = tableView.frame.height
        let temp = tHeight / CGFloat(7)
        return temp > minRowHeight ? temp : minRowHeight
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        switch indexPath.row {
        case 0:
            
            if isShowingPicker{
                
            }else{
                pickerViewType = .PostalCodePicker
            }
            
        default:
            print("")
        }
    }
}

extension HomeSelectionListController: UIPickerViewDataSource, UIPickerViewDelegate{
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        switch pickerViewType {
        case .CountryPicker:
            return 1
        case .PostalCodePicker:
            return getPostalCodeFormat.count
        }
        
    }
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        
        switch pickerViewType {
        case .CountryPicker:
            return getCountryFlagName.count
        case .PostalCodePicker:
            if getPostalCodeFormat[component] == "N"{
                return numericList.count
            }else if getPostalCodeFormat[component] == "S" {
                return 0
            }else{
                return alphabeticList.count
            }
            
        }
        
    }
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String?
    {
        switch pickerViewType {
        case .CountryPicker:
            return getCountryFlagName[row].1
        case .PostalCodePicker:
            if getPostalCodeFormat[component] == "N"{
                return numericList[row]
            }else if getPostalCodeFormat[component] == "S" {
                return ""
            }else {
                return alphabeticList[row]
            }
            
        }
        
    }
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        
        switch pickerViewType {
        case .CountryPicker:
            getCountryPickerRow = row
        case .PostalCodePicker:
            if getPostalCodeFormat[component] == "N"{
                let numericSelected = numericList[pickerView.selectedRow(inComponent: component)]
                print(component, numericSelected)
                getFinalPostalCode[component] = Character(numericSelected)
            }else if getPostalCodeFormat[component] == "S"{
                
            }else{
                let alphabetSelected = alphabeticList[pickerView.selectedRow(inComponent: component)]
                print(component, alphabetSelected)
                getFinalPostalCode[component] = Character(alphabetSelected)
            }
            print(getFinalPostalCode)
            
        }
    }
    func pickerView(_ pickerView: UIPickerView, widthForComponent component: Int) -> CGFloat {
        return 50.0
    }
    func pickerView(_ pickerView: UIPickerView, rowHeightForComponent component: Int) -> CGFloat {
        return 60.0
    }
    func pickerView(_ pickerView: UIPickerView, viewForRow row: Int, forComponent component: Int, reusing view: UIView?) -> UIView {
        
        switch pickerViewType {
        case .CountryPicker:
            let parentView = UIView()
            
            let imageView = UIImageView(frame: CGRect(x: -38, y: 7.5, width: 77, height:45))
            let label = UILabel(frame: CGRect(x: 45, y: 5, width: 80, height: 50))
            
            
            imageView.image = getCountryFlagName[row].0
            label.text = getCountryFlagName[row].1
            
            if #available(iOS 13.0, *) {
                picker.backgroundColor = UIColor.systemGray4
            } else {
                picker.backgroundColor = UIColor.systemGray
                
            }
            parentView.addSubview(label)
            parentView.addSubview(imageView)
            
            
            return parentView
        case .PostalCodePicker:
            let parentView = UIView()
            let label = UILabel(frame: CGRect(x: 10, y: 5, width: 80, height: 50))
            
            if getPostalCodeFormat[component] == "N"{
                label.text =  numericList[row]
            }else if getPostalCodeFormat[component] == "S" {
                label.text = ""
            }else{
                label.text =  alphabeticList[row]
            }
            
            if #available(iOS 13.0, *) {
                picker.backgroundColor = UIColor.systemGray4
            } else {
                picker.backgroundColor = UIColor.systemGray
                
            }
            parentView.addSubview(label)
            
            return parentView
        }
        return UIView()
    }
}

extension HomeSelectionListController: showError{
    func showError(getError: String, getMessage: String) {
        removeActivity()
        showDisconnectAlert(title: getError, message: getMessage)
    }
}

extension HomeSelectionListController{
    func showActivity(title: String) {
        
        DispatchQueue.main.async {
            self.strLabel.removeFromSuperview()
            self.activityIndicator.removeFromSuperview()
            self.effectView.removeFromSuperview()
            
            self.strLabel = UILabel(frame: CGRect(x: 50, y: 0, width: 160, height: 46))
            self.strLabel.text = title
            self.strLabel.font = .systemFont(ofSize: 14, weight: .medium)
            self.strLabel.textColor = UIColor(white: 0.9, alpha: 0.7)
            
            self.effectView.frame = CGRect(x: self.view.frame.midX - self.strLabel.frame.width/2, y: self.view.frame.midY - self.strLabel.frame.height/2 , width: 160, height: 46)
            self.effectView.layer.cornerRadius = 15
            self.effectView.layer.masksToBounds = true
            
            self.activityIndicator = UIActivityIndicatorView(activityIndicatorStyle: .white)
            self.activityIndicator.frame = CGRect(x: 0, y: 0, width: 46, height: 46)
            self.activityIndicator.isUserInteractionEnabled = false
            self.view.isUserInteractionEnabled = false
            self.activityIndicator.startAnimating()
            
            
            self.effectView.contentView.addSubview(self.activityIndicator)
            self.effectView.contentView.addSubview(self.strLabel)
            self.view.addSubview(self.effectView)
            
        }
        
    }
    func removeActivity() {
        
        DispatchQueue.main.async {
            
            self.activityIndicator.stopAnimating()
            self.effectView.removeFromSuperview()
            self.activityIndicator.removeFromSuperview()
            self.view.isUserInteractionEnabled = true
            
        }
        
    }
    func showToas(message : String, seconds: Double){
        
        DispatchQueue.main.async {
            let alert = UIAlertController(title: nil, message: message, preferredStyle: .alert)
            alert.view.backgroundColor = .black
            alert.view.alpha = 0.5
            alert.view.layer.cornerRadius = 15
            self.present(alert, animated: true)
            DispatchQueue.main.asyncAfter(deadline: DispatchTime.now() + seconds) {
                alert.dismiss(animated: true)
            }
            
        }
        
    }
    func showDisconnectAlert(title : String, message: String){
        
        DispatchQueue.main.async {
            let alert = UIAlertController(title: title, message: message, preferredStyle: UIAlertController.Style.alert)
            
            // add an action (button)
            let OkAction = UIAlertAction(title: "OK", style: UIAlertAction.Style.default){
                UIAlertAction in
                
            }
            let cancelAction = UIAlertAction(title: "Cancel", style: UIAlertAction.Style.cancel) {
                UIAlertAction in
                
            }
            alert.addAction(OkAction)
            alert.addAction(cancelAction)
            // show the alert
            self.present(alert, animated: true, completion: nil)
        }
        
    }
}

enum PickerViewType {
    case CountryPicker
    case PostalCodePicker
}
