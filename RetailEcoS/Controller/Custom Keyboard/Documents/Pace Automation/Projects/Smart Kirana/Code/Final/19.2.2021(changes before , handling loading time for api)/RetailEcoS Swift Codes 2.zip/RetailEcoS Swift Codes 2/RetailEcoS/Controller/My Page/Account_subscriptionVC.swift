//
//  Account_subscriptionVC.swift
//  RetailEcoS
//  Account_subscriptionVC
//  Description - This module allows the user to select wether he opts for subscription or convenience fee. If subscription then the options thereof
//  Developed By chezhian A on 2020-12-10.
// © Copyright - Confluence Pte Ltd - Singapore - All Rights reserved

import UIKit

class Account_subscriptionVC: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
