//
//  RetailSelectionCell.swift
//  RetailEcoS
//
//  Created by Pace Automation on 2021-02-03.
//

import UIKit

class RetailSelectionCell: UICollectionViewCell {
    ///mark: outlet
    @IBOutlet weak var viewCell: UIView!
    @IBOutlet weak var imgCell: UIImageView!
    @IBOutlet weak var lblCell: UILabel!
    
    
    
}
