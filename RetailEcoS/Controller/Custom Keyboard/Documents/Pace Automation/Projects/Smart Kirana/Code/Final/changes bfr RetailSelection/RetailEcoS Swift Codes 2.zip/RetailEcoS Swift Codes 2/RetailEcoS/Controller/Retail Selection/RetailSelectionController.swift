//
//  RetailSelectionController.swift
//  RetailEcoS
//
//  Created by Pace Automation on 2021-02-03.
//

import UIKit

class RetailSelectionController: UIViewController {
    
    ///mark: property
    var getModelToGiveDeviceId: DeviceID!
    var getRetailViewModel : RetailSelectionViewModel!
    let sectionInsets = UIEdgeInsets(top: 30.0,left: 0.0,bottom: 20.0,right: 0.0)
    var activityIndicator = UIActivityIndicatorView()
    var strLabel = UILabel()
    let effectView = UIVisualEffectView(effect: UIBlurEffect(style: .dark))
    var getDeviceId: String?
    var retailVerticalDetails : [(UIImage,UIImage,UIImage, Bool,String)] = [(UIImage(named: "imgApparel")!,UIImage(named: "imgApparel")!,UIImage(named: "imgApparel-1")!, false,"Apparel"),(UIImage(named: "imgBeauty")!,UIImage(named: "imgBeauty")!,UIImage(named: "imgBeauty-1")!, false,"Beauty"),(UIImage(named: "imgElectrical")!,UIImage(named: "imgElectrical")!,UIImage(named: "imgElectrical-1")!, false,"Electrical"),(UIImage(named: "imgEyewear")!,UIImage(named: "imgEyewear")!,UIImage(named: "imgEyewear-1")!, false,"Eyewear"),(UIImage(named: "imgFashion")!,UIImage(named: "imgFashion")!,UIImage(named: "imgFashion-1")!, false,"Fashion"),(UIImage(named: "imgFootwear")!,UIImage(named: "imgFootwear")!,UIImage(named: "imgFootwear-1")!, false,"Footwear"),(UIImage(named: "imgFurniture")!,UIImage(named: "imgFurniture")!,UIImage(named: "imgFurniture-1")!, false,"Furniture"),(UIImage(named: "imgGrocery")!,UIImage(named: "imgGrocery")!,UIImage(named: "imgGrocery-1")!, false,"Grocery"),(UIImage(named: "imgAppliance")!,UIImage(named: "imgAppliance")!,UIImage(named: "imgAppliance-1")!, false,"Appliances"),(UIImage(named: "imgJewellery")!,UIImage(named: "imgJewellery")!,UIImage(named: "imgJewellery-1")!, false,"Jewellery"),(UIImage(named: "imgLuggage")!,UIImage(named: "imgLuggage")!,UIImage(named: "imgLuggage-1")!, false,"Luggage"),(UIImage(named: "imgStationary")!,UIImage(named: "imgStationary")!,UIImage(named: "imgStationary-1")!, false,"Stationary")]
    var requestType : RequestType = .post{
        didSet{
            switch requestType{
            case .get:
                print("")
            case .post:
                
                showActivity(title: "Loading")
                guard let getDeviceId = getDeviceId else {
                    showError(getError: "Problem in getting Device Id", getMessage: "")
                    return
                }
                
                getModelToGiveDeviceId = DeviceID(getDeviceId: getDeviceId)
                
                getRetailViewModel.getRetailVerticalDetails(postRequest: HelperClass.shared.urlFetchVerticalDetails, sendDataModel: getModelToGiveDeviceId, vc: self, completion: {
                    self.removeActivity()
                    
                    guard let getRetailDetails = self.getRetailViewModel.getRetailDetails.status.PERMISSION else{
                        return
                    }
                    
                    for i in getRetailDetails{
                        
                        print(i.url)
                        print(i.val)
                        
                    }
                    
                })
                
            }
        }
    }
    
    
    
    
    ///mark: outlet
    @IBOutlet weak var viewCollectionBackground: UIView!
    @IBOutlet weak var retailSelectionCV: UICollectionView!
    
    ///mark: action
    @IBAction func btnGoNext(_ sender: Any) {
        
        self.performSegue(withIdentifier: "showHomeScreen", sender: self)
        
    }
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        initialConfig()
    }
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        guard segue.identifier == "showHomeScreen" else{
            return
        }
        
        let getHomeController = segue.destination as! HomeSelectionListController
        getHomeController.retailVerticalDetails = retailVerticalDetails
    }
    
    
    
    ///mark : function
    func initialConfig() {
        self.viewCollectionBackground.shadowEffects(shadow: .WithBorder, getView: self.viewCollectionBackground, cornerRadius: 50)
        getRetailViewModel = RetailSelectionViewModel()
        getRetailViewModel.showError = self
        getDeviceId = UIDevice.current.identifierForVendor?.uuidString
        requestType = .post
        //        retailSelectionCV.delegate = self
        //        retailSelectionCV.dataSource = self
    }
    
}


///mark: extension
extension RetailSelectionController: showError{
    func showError(getError: String, getMessage: String) {
        removeActivity()
        showDisconnectAlert(title: getError, message: getMessage)
    }
    
}


extension RetailSelectionController{
    func showActivity(title: String) {
        
        DispatchQueue.main.async {
            self.strLabel.removeFromSuperview()
            self.activityIndicator.removeFromSuperview()
            self.effectView.removeFromSuperview()
            
            self.strLabel = UILabel(frame: CGRect(x: 50, y: 0, width: 160, height: 46))
            self.strLabel.text = title
            self.strLabel.font = .systemFont(ofSize: 14, weight: .medium)
            self.strLabel.textColor = UIColor(white: 0.9, alpha: 0.7)
            
            self.effectView.frame = CGRect(x: self.view.frame.midX - self.strLabel.frame.width/2, y: self.view.frame.midY - self.strLabel.frame.height/2 , width: 160, height: 46)
            self.effectView.layer.cornerRadius = 15
            self.effectView.layer.masksToBounds = true
            
            self.activityIndicator = UIActivityIndicatorView(activityIndicatorStyle: .white)
            self.activityIndicator.frame = CGRect(x: 0, y: 0, width: 46, height: 46)
            self.activityIndicator.isUserInteractionEnabled = false
            self.view.isUserInteractionEnabled = false
            self.activityIndicator.startAnimating()
            
            
            self.effectView.contentView.addSubview(self.activityIndicator)
            self.effectView.contentView.addSubview(self.strLabel)
            self.view.addSubview(self.effectView)
            
        }
        
    }
    func removeActivity() {
        
        DispatchQueue.main.async {
            
            self.activityIndicator.stopAnimating()
            self.effectView.removeFromSuperview()
            self.activityIndicator.removeFromSuperview()
            self.view.isUserInteractionEnabled = true
            
        }
        
    }
    func showToas(message : String, seconds: Double){
        
        DispatchQueue.main.async {
            let alert = UIAlertController(title: nil, message: message, preferredStyle: .alert)
            alert.view.backgroundColor = .black
            alert.view.alpha = 0.5
            alert.view.layer.cornerRadius = 15
            self.present(alert, animated: true)
            DispatchQueue.main.asyncAfter(deadline: DispatchTime.now() + seconds) {
                alert.dismiss(animated: true)
            }
            
        }
        
    }
    func showDisconnectAlert(title : String, message: String){
        
        DispatchQueue.main.async {
            let alert = UIAlertController(title: title, message: message, preferredStyle: UIAlertController.Style.alert)
            
            // add an action (button)
            let OkAction = UIAlertAction(title: "OK", style: UIAlertAction.Style.default){
                UIAlertAction in
                
            }
            let cancelAction = UIAlertAction(title: "Cancel", style: UIAlertAction.Style.cancel) {
                UIAlertAction in
                
            }
            alert.addAction(OkAction)
            alert.addAction(cancelAction)
            // show the alert
            self.present(alert, animated: true, completion: nil)
        }
        
    }
}


extension RetailSelectionController : UICollectionViewDelegateFlowLayout {
    func collectionView(_ collectionView: UICollectionView,
                        layout collectionViewLayout: UICollectionViewLayout,
                        sizeForItemAt indexPath: IndexPath) -> CGSize {
        
        
        let width  = (self.retailSelectionCV.frame.size.width ) / 5
        let height  = (self.retailSelectionCV.frame.size.height ) / 4
        
        return CGSize(width: width, height: height)
    }
    func collectionView(_ collectionView: UICollectionView,
                        layout collectionViewLayout: UICollectionViewLayout,
                        insetForSectionAt section: Int) -> UIEdgeInsets {
        return sectionInsets
    }
    func collectionView(_ collectionView: UICollectionView,
                        layout collectionViewLayout: UICollectionViewLayout,
                        minimumLineSpacingForSectionAt section: Int) -> CGFloat {
        return 20.0
    }
}


///Mark: Collection View Delegate
extension RetailSelectionController: UICollectionViewDelegate,UICollectionViewDataSource{
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        
        return 12
        
    }
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        if let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "RetailSelectionCell", for: indexPath) as? RetailSelectionCell{
            
            //            cell.viewCell.shadowEffects(shadow: .WithBorder, getView: cell.viewCell, cornerRadius: 10)
            cell.imgCell.image = retailVerticalDetails[indexPath.row].0
            cell.lblCell.text = retailVerticalDetails[indexPath.row].4
            return cell
            
        }
        
        return UICollectionViewCell()
        
    }
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        
        if let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "RetailSelectionCell", for: indexPath) as? RetailSelectionCell{
            
            retailVerticalDetails[indexPath.row].3 = !retailVerticalDetails[indexPath.row].3
            
            if retailVerticalDetails[indexPath.row].3 {
                retailVerticalDetails[indexPath.row].0 = retailVerticalDetails[indexPath.row].2
                
                for i in 0..<12{
                    if i != indexPath.row{
                        retailVerticalDetails[i].0 = retailVerticalDetails[i].1
                        retailVerticalDetails[i].3 = false
                    }
                }
                
                collectionView.reloadData()
            }else{
                
                retailVerticalDetails[indexPath.row].0 = retailVerticalDetails[indexPath.row].1
                collectionView.reloadData()
            }
        }
        
    }
}

