//
//  My_Setting_LanguageVC.swift
//  RetailEcoS
//  My_Setting_LanguageVC
//  Description - This module allows the user to set his preferred language of operation
//  Developed By:
// © Copyright - Confluence Pte Ltd - Singapore - All Rights reserved

import UIKit

class My_Setting_LanguageVC: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
