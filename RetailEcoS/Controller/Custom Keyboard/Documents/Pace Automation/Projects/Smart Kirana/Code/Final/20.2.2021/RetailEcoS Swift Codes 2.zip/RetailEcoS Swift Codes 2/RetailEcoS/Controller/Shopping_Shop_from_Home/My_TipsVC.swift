//
//  My_TipsVC.swift
//  RetailEcoS
//  My_TipsVC
//  Description - This module accepts the tip value in either absolute value or as a percentage of sale value.
//  Developed By
// © Copyright - Confluence Pte Ltd - Singapore - All Rights reserved


import UIKit

class My_TipsVC: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
