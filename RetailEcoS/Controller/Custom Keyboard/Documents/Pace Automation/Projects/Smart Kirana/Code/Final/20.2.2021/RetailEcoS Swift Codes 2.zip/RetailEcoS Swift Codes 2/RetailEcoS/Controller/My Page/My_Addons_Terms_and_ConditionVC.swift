//
//  My_Addons_Terms_and_ConditionVC.swift
//  RetailEcoS
//  My_Addons_Terms_and_ConditionVC
// Description - This module provides the complete terms and condition of service and the publication date and expects the user to confirm acceptance of the entire terms and conditions of service
//  Developed By
// © Copyright - Confluence Pte Ltd - Singapore - All Rights reserved

import UIKit

class My_Addons_Terms_and_ConditionVC: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
