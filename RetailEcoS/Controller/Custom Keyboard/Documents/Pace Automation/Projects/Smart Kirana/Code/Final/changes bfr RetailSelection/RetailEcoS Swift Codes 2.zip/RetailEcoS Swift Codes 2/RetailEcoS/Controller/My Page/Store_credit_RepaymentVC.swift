//
//  Store_credit_RepaymentVC.swift
//  RetailEcoS
//  Store_credit_RepaymentVC
//  Description - This module allows customer select either a line item or total and clear the payment using credit card
//  Developed BY:
// © Copyright - Confluence Pte Ltd - Singapore - All Rights reserved

import UIKit

class Store_credit_RepaymentVC: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
